let arr=[6,7,8,9,10];
arr.splice(0,1);
console.log(arr);
