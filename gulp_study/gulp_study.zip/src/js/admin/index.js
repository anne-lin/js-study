var arr=[12,22,32,42,52];
arr.splice(0,1);
console.log(arr);
